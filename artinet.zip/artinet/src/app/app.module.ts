import { NgModule, ErrorHandler } from '@angular/core';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { AboutPage } from '../pages/about/about';
import { ContactPage } from '../pages/contact/contact';
import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';
import { Data } from '../providers/data';
import { Storage } from '@ionic/storage';

import { InicioPage } from '../pages/inicio/inicio'
import { TranslateModule,TranslateLoader, TranslateStaticLoader } from 'ng2-translate/ng2-translate';
import { Http } from '@angular/http';

/* COMPONENETES */
import { FlipCardComponent } from '../components/flip-card/flip-card'


export function provideStorage() {
  return new Storage(  [     'localstorage',   ],   {     name: 'artinetDB',     storeName: 'artinetDBData',   } );
}
export function createTranslateLoader(http: Http) {
    return new TranslateStaticLoader(http, 'assets/i18n', '.json');
}


@NgModule({
  declarations: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,
    InicioPage,
    FlipCardComponent
  ],
  imports: [
    IonicModule.forRoot(MyApp),
    TranslateModule.forRoot({
      provide: TranslateLoader,
      useFactory: (createTranslateLoader),
      deps: [Http]
    })
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,
    InicioPage
  ],
  providers: [Data,Storage,
                {provide: ErrorHandler, useClass: IonicErrorHandler},
                {provide: Storage, useFactory: provideStorage}
              ]
})
export class AppModule {}
