

import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Data } from '../../providers/data';

import { Storage } from '@ionic/storage';
import { App, ViewController } from 'ionic-angular';

import { InicioPage } from '../inicio/inicio';
import {TranslateService} from 'ng2-translate';
import { Http } from '@angular/http';

@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {

  paises = [];
  paisesBckp = [];
  busqueda = [];
  artistas = [];
  artistasBckp = [];

 constructor(public navCtrl: NavController,
              public data: Data,
              public storage: Storage,
              public viewCtrl: ViewController,
              public appCtrl: App,
              public translate: TranslateService,
              public http: Http) {
   }

     ionViewDidLoad() {

       this.cargaPrincipal();

    /*   $scope.canciones = "";
          if (busqueda != "") {
            direc = 'https://api.spotify.com/v1/search?q=' +
              busqueda + '&type=artist&limit=' + limit + '&offset=' + offset;

            $http({
              method: 'GET',
              url: direc
            }).then(function successCallback(response) {
              var datos = response.data;

              $scope.listado = datos.artists.items;
              for (a in datos.artists.items) {
                console.log(datos.artists.items[a].name);
              }
              console.log('------------------------------------------------------');
            }, function errorCallback(response) {});
          } else {
            $scope.listado = "";
          }*/
     }

     cargaPrincipal(){
       this.data.llamadaGet("https://restcountries.eu/rest/v2/all").subscribe(
          data => {
            console.log(data);
            this.paises = data;
            this.paisesBckp = data;
            console.log("DATO -->" + data.length );
            if(data.length > 0 ){
              for (var i = 0; i < data.length; i++){
                   var obj = data[i];
                   try {
                     //console.log("DATO -->" + data[i].translations.es);
                   } catch (e) {
                     console.log("DATO --> MOOOOOOO");
                   }
               }
             }
          },
          err => {
            console.log("Error GET " + err);
          },
          // EJECUTAR ALGO DESPUES DEL GET AQUI !
          () => console.log('Fin GET')
      );
     }

     seleccionar(ev){
         var val = ev;
         console.log(val);
         ev.target.parent.className = "verde";
     }

     getItems(ev) {
        var val = ev.target.value;

        if (val === undefined){
          val = "";
        }

        if (val.length > 2 ){

            val= val + '*';

           this.data.llamadaGet("http://api.spotify.com/v1/search?q="+val+"&type=artist&limit=10&offset=0").subscribe(
              data => {
                console.log(data);
                this.artistas = data.artists.items;
                this.artistasBckp = data.artists.items;
                data = data.artists.items;

                console.log("DATO -->" + data.length );
                if(data.length > 0 ){
                  for (var i = 0; i < data.length; i++){
                       var obj = data[i];
                       try {
                         data[i].images = data[i].images[0].url;
                       } catch (e) {
                         data[i].images = "http://k14.kn3.net/FAFFD4944.jpg";
                         console.log("DATO --> MOOOOOOO");
                       }
                   }
                 }
              },
              err => {
                console.log("Error GET " + err);
              },
              // EJECUTAR ALGO DESPUES DEL GET AQUI !
              () => console.log('Fin GET')
          );
        }else{
          // this.cargaPrincipal();
        }

   }

}
