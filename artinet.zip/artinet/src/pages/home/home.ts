

import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Data } from '../../providers/data';

import { Storage } from '@ionic/storage';
import { App, ViewController } from 'ionic-angular';

import { InicioPage } from '../inicio/inicio';
import {TranslateService} from 'ng2-translate';
import { Http } from '@angular/http';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  festivales = [];
  festivalesBckp = [];
  busqueda = [];
  mostrar : boolean = true;

 constructor(public navCtrl: NavController,
              public data: Data,
              public storage: Storage,
              public viewCtrl: ViewController,
              public appCtrl: App,
              public translate: TranslateService,
              public http: Http) {
   }

   mostrarOcultar(){
     this.mostrar = !this.mostrar;
   }
  ionViewDidLoad() {

       this.data.llamadaGet('http://localhost:3000/festivals/listado').subscribe(
          data => {

            this.festivales = data;
            this.festivalesBckp = data;

            if(data.length > 0 ){
              for (var i = 0; i < data.length; i++){
                   var obj = data[i];
                   console.log("DATO -->"+ obj.titulo);
               }
             }
          },
          err => {
            console.log("Error GET " + err);
          },
          // EJECUTAR ALGO DESPUES DEL GET AQUI !
          () => console.log('Fin GET')
      );

     }

     getItems(ev) {

       var val = ev.target.value;
       this.festivales = this.festivalesBckp;

       if (val && val.trim() != '') {
         this.festivales = this.festivales.filter((item) => {
           return (item.name.toLowerCase().indexOf(val.toLowerCase()) > -1);
           //return 'Rotot';
         })
       }else{
         return this.festivales = this.festivalesBckp;
       }
   }
}
