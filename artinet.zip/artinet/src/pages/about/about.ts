

import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Data } from '../../providers/data';

import { Storage } from '@ionic/storage';
import { App, ViewController } from 'ionic-angular';

import { InicioPage } from '../inicio/inicio';
import {TranslateService} from 'ng2-translate';
import { Http } from '@angular/http';

@Component({
  selector: 'page-about',
  templateUrl: 'about.html'
})
export class AboutPage {

  artistas = [];
  artistasBckp = [];
  busqueda = [];
  elementoHijo : String;
 constructor(public navCtrl: NavController,
              public data: Data,
              public storage: Storage,
              public viewCtrl: ViewController,
              public appCtrl: App,
              public translate: TranslateService,
              public http: Http) {
   }

     ionViewDidLoad() {
       this.cargaPrincipal();
     }

     cargaPrincipal(){
       this.elementoHijo = "dDddddd";
       this.data.llamadaGet("http://api.spotify.com/v1/search?q="+ 'a' +"&type=artist&limit=10&offset=0").subscribe(
          data => {
            console.log(data);
            this.artistas = data.artists.items;
            this.artistasBckp = data.artists.items;
            data = data.artists.items;

            console.log("DATO -->" + data.length );
            if(data.length > 0 ){
              for (var i = 0; i < data.length; i++){
                   var obj = data[i];
                   try {
                     console.log("DATO -->" + data[i].images[0].url);
                     data[i].images = data[i].images[0].url;
                   } catch (e) {
                     data[i].images = "";
                     console.log("DATO --> NOOOOOOO");
                   }
               }
             }
          },
          err => {
            console.log("Error GET " + err);
          },
          // EJECUTAR ALGO DESPUES DEL GET AQUI !
          () => console.log('Fin GET')
      );
     }

     getItems(ev) {
        var val = ev.target.value;

        if (val === undefined){
          val = "";
        }

        if (val.length > 2 ){

            val= val + '*';

           this.data.llamadaGet("http://api.spotify.com/v1/search?q="+val+"&type=artist&limit=10&offset=0").subscribe(
              data => {
                console.log(data);
                this.artistas = data.artists.items;
                this.artistasBckp = data.artists.items;
                data = data.artists.items;

                console.log("DATO -->" + data.length );
                if(data.length > 0 ){
                  for (var i = 0; i < data.length; i++){
                       var obj = data[i];
                       try {
                         data[i].images = data[i].images[0].url;
                       } catch (e) {
                         data[i].images = "http://k14.kn3.net/FAFFD4944.jpg";
                         console.log("DATO --> MOOOOOOO");
                       }
                   }
                 }
              },
              err => {
                console.log("Error GET " + err);
              },
              // EJECUTAR ALGO DESPUES DEL GET AQUI !
              () => console.log('Fin GET')
          );
        }else{
          this.cargaPrincipal();
        }

   }
}
