import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { Storage } from '@ionic/storage';
import { App, ViewController } from 'ionic-angular';

import { TabsPage } from '../tabs/tabs';
import {TranslateService} from 'ng2-translate';
import { Data } from '../../providers/data';
import { Http } from '@angular/http';


@Component({
  selector: 'page-inicio',
  templateUrl: 'inicio.html'
})
export class InicioPage {

  //todo = {};
  todo = {"correo":"davidgarciasantes@gmail.com",
          "contrasenya":"212211"};
  nombre:any;

  constructor(public navCtrl: NavController, public navParams: NavParams,
              public storage: Storage,
              public viewCtrl: ViewController,
              public appCtrl: App,
              public translate: TranslateService,
              public data: Data,
              public http: Http) {

              translate.setDefaultLang('es');
              this.data.limpiarLocalStorage();
  }


  logForm(opcion) {

    //this.data.llamadaGet('http://localhost/workspace/artinet/public/irInicio',).subscribe(
    //this.data.llamadaGet('http://178.62.74.67:3000/1',).subscribe(
    //alert( JSON.stringify(this.data.llamadaGet('https://localhost:3000/1')) );
    this.data.llamadaGet('http://localhost:3000/1').subscribe(
    //this.data.llamadaPost('http://localhost/workspace/cavallers/public_html/misNoticias',this.todo).subscribe(

    //this.data.llamadaPost('http://localhost/workspace/artinet/public/inicio/store',this.todo).subscribe(
       data => {
         alert(JSON.stringify(data));
          if(data.length > 0 ){

           for (var i = 0; i < data.length; i++){
                var obj = data[i];
                console.log("DATO -->"+ obj.name);
            }
            this.data.limpiarLocalStorage();
            this.data.guardarLocalStorage("artinetCurrentUser",obj.name);
            this.appCtrl.getRootNav().push(TabsPage);
          }else{

          }
       },
       err => {
         alert("Error GET " + err);
         console.log("Error GET " + err);
       },
       // EJECUTAR ALGO DESPUES DEL GET AQUI !
       () => console.log('Fin GET')
   );
   console.log("Error GET " );
   // EJECUTAR ALGO DESPUES DEL GET ANTES EN EL FIN !
  }

  ionViewDidLoad() {

    this.storage.ready().then(() => {
    this.storage.get("artinetCurrentUser").then((val) => {
      if ( val != "" &&  val != null ){
         this.appCtrl.getRootNav().push(TabsPage);
      }
    })
    });
  }

  verDato(evento){
    console.log("Nombre " +  evento.target.value);
  }


}
