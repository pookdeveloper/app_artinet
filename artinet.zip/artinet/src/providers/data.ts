import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

import { Storage } from '@ionic/storage';

/*
  Generated class for the Data provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class Data {

  constructor(public http: Http, public storage: Storage ) {
    console.log('Hello Data Provider');
  }


  llamadaGet(urlDestino) {
    //var url = urlDestino; //'http://localhost/workspace/artinet/public/irInicio';
    

    var response = this.http.get(urlDestino).map(res => res.json());
    return response;
  }

  llamadaPost(urlDestino, data) {
    //var url = urlDestino; //'http://localhost/workspace/artinet/public/irInicio';
    var response = this.http.post(urlDestino, data).map(res => res.json());
    return response;

/*    this.http.post(link, data)
           .subscribe(data => {
            this.data.response = data._body;
           }, error => {
               console.log("Oooops!");
           });*/
  }


  guardarLocalStorage(clave, valor){
    this.storage.ready().then(() => {
     this.storage.set(clave, valor);
   });
  }


  /* Limpiamos los datos de LocalStorage*/
  limpiarLocalStorage(){
    this.storage.ready().then(() => {
     this.storage.clear();
   });
  }


}
