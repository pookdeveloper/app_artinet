import { Component, Input } from '@angular/core';

/*
  Generated class for the FlipCard component.

  See https://angular.io/docs/ts/latest/api/core/index/ComponentMetadata-class.html
  for more info on Angular 2 Components.
*/
@Component({
  selector: 'flip-card',
  templateUrl: 'flip-card.html'
})
export class FlipCardComponent {

  flipped: boolean = false;
//  opacidad: boolean = false;

  @Input('elemen') elemento: String;
  @Input('est') estilo: String;
   constructor() {
   }

   flip(dato){
     //this.opacidad = !this.opacidad;

     this.flipped = !this.flipped;
   }


}
